const Porcentaje = () => {
  return (
    <div className="col">
        <h2>Porcentaje censado</h2>
        <div>grafico o numerito de porcentaje</div>
    </div>
  )
}

export default Porcentaje