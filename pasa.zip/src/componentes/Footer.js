const Footer = () => {
  return (
    <div className="footer">
        <h3>Obligatorio taller de front-end</h3>
        <h4>Renzo De Leon - N°290199 || Emiliano Olivera - N°000000</h4>
    </div>
  )
}

export default Footer